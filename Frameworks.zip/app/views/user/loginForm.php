<form name="loginForm" action="" method="post" enctype="multipart/formdata">
	<input type="text" name="username" />
	<input type="password" name="password" />
	<input type="submit" name="sendLoginForm" value="Login" />
        <input type="file" name="fisier" value="test" />
</form>