<h1><?php echo $vars['titlu']; ?></h1>
<h2><?php echo $vars['subtitlu']; ?></h2>
Nunc pellentesque. Sed vestibulum blandit nisl. Quisque elementum convallis purus. Suspendisse potenti. Donec nulla est, laoreet quis, pellentesque i 